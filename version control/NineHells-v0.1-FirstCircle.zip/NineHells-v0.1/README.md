# NineHells v0.1 — First Circle

A working cursed forum prototype where nine components have mandatory semantic jobs:

1. HTML — structural forum database
2. CSS — authorization policy source
3. JavaScript — event broker
4. PHP — sessions/login/read state
5. Python — inter-component exception protocol + HTTP coordinator
6. TypeScript — referential integrity validation
7. C++ — moderation policy compiler
8. Unix — FIFOs, processes, locks and filesystem runtime objects
9. Directories — source/storage/linker; runtime source is reconstructed from directory names

## Requirements
Linux, Python 3, PHP CLI, Node.js, TypeScript (`tsc`), and a C++ compiler (`g++`).

## Run

    ./smoke-test.sh
    ./run.sh 127.0.0.1 9099

Open http://127.0.0.1:9099

The smoke test exercises register -> login -> create thread -> reply -> read -> CSS permission check -> TypeScript integrity -> C++ moderation -> JavaScript notification, and also verifies that each of the nine components is required.
