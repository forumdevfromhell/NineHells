#!/usr/bin/env python3
from pathlib import Path
import base64,hashlib,os,sys
R=Path(__file__).resolve().parent
parts=[]
for d in sorted((R/'hellsrc').iterdir()):
    if d.is_dir(): parts.append(d.name.split('_',1)[1])
s=''.join(parts); data=base64.b32decode(s+'='*((8-len(s)%8)%8))
if hashlib.sha256(data).hexdigest()!=(R/'RUNTIME.sha256').read_text().strip(): raise SystemExit('directory-source checksum failure')
# Source exists only transiently in an anonymous Linux memfd.
if not hasattr(os,'memfd_create'): raise SystemExit('NineHells requires Linux memfd_create')
fd=os.memfd_create('ninehells-runtime'); os.write(fd,data); os.lseek(fd,0,0)
os.execv(sys.executable,[sys.executable,f'/proc/self/fd/{fd}',*sys.argv[1:]])
