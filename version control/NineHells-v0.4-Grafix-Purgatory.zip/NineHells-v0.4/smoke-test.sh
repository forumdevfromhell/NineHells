#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export NINEHELLS_ROOT="$PWD"
for x in python3 php node tsc g++; do command -v "$x" >/dev/null || { echo "missing: $x"; exit 1; }; done
rm -rf data runtime
mkdir -p data/users data/threads runtime/generated
: > runtime/forum.lock
mkfifo runtime/events.fifo
# Reconstruct the cross-language compiler-error Ouroboros first.
NINEHELLS_RECONSTRUCT_ONLY=1 python3 boot.py
[[ -s runtime/generated/events.js && -s runtime/generated/integrity.ts && -s runtime/generated/moderation.cpp ]]
# Reconstruct directory-held runtime into a temporary test copy only.
python3 - <<'PY'
from pathlib import Path
import base64,hashlib
r=Path('.'); s=''.join(d.name.split('_',1)[1] for d in sorted((r/'hellsrc').iterdir()) if d.is_dir()); b=base64.b32decode(s+'='*((8-len(s)%8)%8)); assert hashlib.sha256(b).hexdigest()==(r/'RUNTIME.sha256').read_text().strip(); Path('runtime/test_runtime.py').write_bytes(b)
PY
python3 - <<'PY'
import importlib.util, pathlib, sys
sys.path.insert(0,str(pathlib.Path('src').resolve()))
p=pathlib.Path('runtime/test_runtime.py').resolve(); spec=importlib.util.spec_from_file_location('nine',p); n=importlib.util.module_from_spec(spec); spec.loader.exec_module(n)
assert n.register('alice','hellpass')
s=n.login('alice','hellpass'); assert s and n.who(s)=='alice'
t=n.create_thread('alice','First Circle','Nine components or death'); assert t
assert n.reply('alice',t,'reply from hell')
assert n.css_allow('guest','create') is False and n.css_allow('user','create') is True
assert n.unix_allow('guest','create') is False and n.unix_allow('user','create') is True
assert n.reality('user','create') is True
assert n.integrity()
assert n.moderate('clean post') and not n.moderate('NINEHELLS_BANNED')
assert 'First Circle' in n.render('alice') and 'reply from hell' in n.render('alice')
assert pathlib.Path('runtime/events.log').exists()
assert n.role_for('alice') == 'admin'
assert n.like('alice',t) and (pathlib.Path('data/threads')/t/'likes'/'alice').exists()
assert n.like('alice',t) and not (pathlib.Path('data/threads')/t/'likes'/'alice').exists()
assert 'NINEHELLS' in n.render('alice') and 'Logout' in n.render('alice')
# Force disagreement: CSS says user may reply, Unix says no. Consensus must reject.
p=pathlib.Path('policy/unix/reply'); old=p.stat().st_mode & 0o777; p.chmod(0o600)
try:
    assert n.css_allow('user','reply') is True
    assert n.unix_allow('user','reply') is False
    assert n.reality('user','reply') is False
    assert pathlib.Path('runtime/reality-disagreements.log').exists()
finally:
    p.chmod(old)
print('NINEHELLS_V04_POLISH_OK')
print('NINEHELLS_REALITY_CONSENSUS_OK')
print('NINEHELLS_END_TO_END_OK')
PY
# Nine required-component death tests. Each must break a meaningful capability.
python3 - <<'PY'
from pathlib import Path
import shutil, subprocess, tempfile, os
root=Path('.').resolve()
checks=[
 ('HTML','structure/forum.html'),('CSS','policy/auth.css'),('JavaScript','carriers/javascript-in-typescript.ts'),('PHP','src/session.php'),
 ('Python','src/protocol.py'),('TypeScript','carriers/typescript-in-cpp.cpp'),('C++','carriers/cpp-in-javascript.js'),('Unix','policy/unix/reply'),('Directories','hellsrc')]
for name,rel in checks:
 p=root/rel; q=root/'runtime'/('held_'+name.replace('/','_'))
 p.rename(q)
 try:
  if name=='Directories':
   r=subprocess.run(['python3','boot.py'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=3)
   assert r.returncode!=0
  elif name=='Python':
   # importing reconstructed coordinator must fail without exception protocol
   r=subprocess.run(['python3','-c','import runpy; runpy.run_path("runtime/test_runtime.py")'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
   assert r.returncode!=0
  elif name in ('JavaScript','TypeScript','C++'):
   env=os.environ.copy(); env['NINEHELLS_RECONSTRUCT_ONLY']='1'
   r=subprocess.run(['python3','boot.py'],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
   assert r.returncode!=0
  else:
   code='''import importlib.util,pathlib,sys\nsys.path.insert(0,str(pathlib.Path("src").resolve()))\np=pathlib.Path("runtime/test_runtime.py").resolve();s=importlib.util.spec_from_file_location("n",p);n=importlib.util.module_from_spec(s);s.loader.exec_module(n)\n'''
   expr={'HTML':'n.render()','CSS':'n.css_allow("user","create")','JavaScript':'n.event("x",{})','PHP':'n.php("new","x")','TypeScript':'n.integrity()','C++':'n.moderate("x")','Unix':'n.unix_allow("user","reply")'}[name]
   r=subprocess.run(['python3','-c',code+expr],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
   assert r.returncode!=0 or r.stdout.strip()=='False', (name,r.stdout)
  print('HELL_REQUIRED_OK',name)
 finally:q.rename(p)
print('NINEHELLS_COMPONENT_DEATH_TESTS_OK')
PY
rm -f runtime/test_runtime.py runtime/generated/relations.ts runtime/moderator
printf 'NINEHELLS_SMOKE_OK\n'
