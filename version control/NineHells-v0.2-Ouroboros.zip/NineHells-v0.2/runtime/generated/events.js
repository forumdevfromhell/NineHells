// JS is the event broker. stdin JSON -> EventTarget -> stdout JSON acknowledgement.
const readline = require('readline');
const bus = new EventTarget();
bus.addEventListener('forum', ev => process.stdout.write(JSON.stringify({delivered:true,event:ev.detail})+'\n'));
const rl = readline.createInterface({input:process.stdin, terminal:false});
rl.on('line', line => { const msg=JSON.parse(line); const ev=new Event('forum'); ev.detail=msg; queueMicrotask(()=>bus.dispatchEvent(ev)); });
