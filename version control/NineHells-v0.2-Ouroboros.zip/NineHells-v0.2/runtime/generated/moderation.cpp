#include <string_view>
#include <cstdlib>
constexpr bool forbidden(std::string_view s) {
    return s.find("NINEHELLS_BANNED") != std::string_view::npos;
}
int main(int argc, char **argv) {
    if (argc < 2) return 64;
    return forbidden(argv[1]) ? 96 : 0;
}
