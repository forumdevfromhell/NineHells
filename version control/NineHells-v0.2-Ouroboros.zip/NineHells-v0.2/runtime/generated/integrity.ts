// TypeScript is the referential-integrity oracle. The coordinator generates relations.ts.
import { USERS, THREADS, REPLIES } from "./relations";
type User = keyof typeof USERS;
type Thread = keyof typeof THREADS;
const _threadAuthors: { [K in Thread]: User } = THREADS;
const _replyAuthors: { [K in keyof typeof REPLIES]: User } = REPLIES;
void _threadAuthors; void _replyAuthors;
