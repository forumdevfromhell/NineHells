# NineHells v0.2 — Ouroboros

A working cursed forum where nine components have mandatory semantic jobs and no component gets the whole truth.

## The nine Hells

1. HTML — structural forum database
2. CSS — authorization policy source
3. JavaScript — event broker
4. PHP — sessions/login/read state
5. Python — inter-component exception protocol + HTTP coordinator
6. TypeScript — referential integrity validation
7. C++ — moderation policy compiler
8. Unix — FIFOs, processes, locks and filesystem runtime objects
9. Directories — source/storage/linker; the main runtime is reconstructed from directory names

## v0.2: Ouroboros

The three compiler/runtime languages no longer keep their own source normally:

- JavaScript source is encoded into deliberate TypeScript compiler errors.
- TypeScript source is encoded into deliberate C++ compiler errors.
- C++ source is encoded into a deliberate JavaScript parser error.
- If any carrier unexpectedly compiles/parses successfully, startup treats the installation as corrupt.
- The reconstructed files exist only under `runtime/generated/` and are disposable.
- `version control/` contains ZIP snapshots of previous releases so only the newest tree needs to be pushed.

The cycle is: `TS fails -> JS`, `C++ fails -> TS`, `JS fails -> C++`.

## Version history

### v0.1 — First Circle

First working NineHells prototype. Register/login/thread/reply/read, CSS permissions, TypeScript integrity, C++ moderation, JavaScript events, PHP sessions, Python exception IPC, Unix FIFOs/locks, HTML structure, and directory-encoded main runtime. Every Hell had a component-death test.

### v0.2 — Ouroboros

Added cross-language diagnostic storage for JavaScript, TypeScript and C++; removed their ordinary source files; made expected compiler/parser failure part of bootstrap integrity; added bundled previous-release ZIPs under `version control/`; updated smoke tests for the new source chain.

## Requirements

Linux, Python 3, PHP CLI, Node.js, TypeScript (`tsc`), and `g++`.

## Run

    ./smoke-test.sh
    ./run.sh 127.0.0.1 9099

Open `http://127.0.0.1:9099`.
